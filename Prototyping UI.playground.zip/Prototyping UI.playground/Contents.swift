// TurkishKit
// Playground: Kullanıcı Arayüzü Prototipleme
// Telif Hakkı © TurkishKit. Tüm hakları saklıdır.

import UIKit
import PlaygroundSupport

class MyViewController: UIViewController {
    var cardBottomConstraint: NSLayoutConstraint!
    
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white
        self.view = view
        
        setupButton()
        setupCard()
    }
    
    func setupButton() {
        let button = UIButton(frame: CGRect(x: 120, y: 30, width: 300, height: 50))
        button.backgroundColor = .red
        button.layer.cornerRadius = 20
        button.setTitle("Animate", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.addTarget(self, action: #selector(animateCard), for: .touchUpInside)
        view.addSubview(button)
    }
    
    func setupCard() {
        let card = UIView(frame: CGRect(x: 20, y: 105, width: 516, height: 300))
        card.layer.cornerRadius = 20
        card.backgroundColor = .black
        view.addSubview(card)
        
        let label = UILabel(frame: CGRect(x: 10, y: 10, width: 250, height: 300))
        label.text = "Welcome \n to \n WWDC!"
        label.numberOfLines = 3
        label.textColor = .white
        label.font = UIFont.boldSystemFont(ofSize: 55)
        card.addSubview(label)
        
        card.translatesAutoresizingMaskIntoConstraints = false
        card.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10).isActive = true
        card.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10).isActive = true
        card.heightAnchor.constraint(equalToConstant: 300).isActive = true

        cardBottomConstraint = card.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: 500)
        cardBottomConstraint.isActive = true
    }
    
    @objc func animateCard() {
        cardBottomConstraint.constant = -10
        
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
}

let view = MyViewController()
view.preferredContentSize = CGSize(width: 556, height: 417)
PlaygroundPage.current.liveView = view
