// TurkishKit
// Playground: Animasyonlar
// Telif Hakkı © TurkishKit. Tüm hakları saklıdır.

import UIKit
import PlaygroundSupport

let view = UIView(frame: CGRect(x: 0, y: 0, width: 640, height: 480))
view.backgroundColor = UIColor.init(cgColor: CGColor(srgbRed: 26/255, green: 25/255, blue: 39/255, alpha: 1.0))
PlaygroundPage.current.liveView = view

let image = UIImageView(frame: CGRect(x: 230, y: -180, width: 180, height: 180))
image.image = UIImage(named: "TurkishKit")
image.alpha = 0
view.addSubview(image)

let button = UIButton(frame: CGRect(x: 280, y: 200, width: 80, height: 80))
button.backgroundColor = .red
button.setTitle("Animate", for: .normal)
button.layer.cornerRadius = 40
view.addSubview(button)

let label = UILabel(frame: CGRect(x: 170, y: 480, width: 300, height: 60))
label.text = "TurkishKit"
label.textAlignment = .center
label.textColor = .white
label.font = UIFont(name: "AvenirNext-DemiBold", size: 60.0)
label.alpha = 0
view.addSubview(label)

class Responder: NSObject {
    @objc func animate() {
        UIView.animate(withDuration: 2) { () -> Void in
            image.frame = CGRect(x: 230, y: 100, width: 180, height: 180)
            label.frame = CGRect(x: 170, y: 260, width: 300, height: 60)
            
            image.alpha = 1
            label.alpha = 1
            button.alpha = 0
        }
    }
}

let responder = Responder()
button.addTarget(responder, action: #selector(responder.animate), for: .touchUpInside)
